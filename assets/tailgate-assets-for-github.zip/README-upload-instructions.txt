Upload these five files into the repository folder: assets/

Expected paths used by the updated pages:
assets/tailgate-logo.png
assets/tailgate-epic-hero.png
assets/tailgate-daytime-partying.webp
assets/tailgate-beach-club-full-view.webp
assets/tailgate-floating-icon.png
